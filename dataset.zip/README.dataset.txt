# building detection > Roboflow Instant 1 [Eval]
https://universe.roboflow.com/iftikhar-ali/building-detection-lzkni

Provided by a Roboflow user
License: CC BY 4.0

